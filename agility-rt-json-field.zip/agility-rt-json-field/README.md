# agility-rt-json-field
Custom field rich text with json output in Agility CMS
